<?php
new Assets(CSS_PATH . '/styles.css');