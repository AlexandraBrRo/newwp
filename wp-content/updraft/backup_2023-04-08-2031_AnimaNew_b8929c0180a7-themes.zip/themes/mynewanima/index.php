<?php get_header(); ?>

<?php the_content(); ?>
<?php the_title(); ?>

<?php get_sidebar(); ?>

<?php get_footer(); ?>
