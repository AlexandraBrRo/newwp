
// $(function () {
//     $('.owl-carousel').owlCarousel({
//         margin:10,
//         loop:true,
//         autoWidth:true,
//         items:4
//     })
// })
// $('.owl-carousel').owlCarousel({
//     margin:10,
//     loop:true,
//     autoWidth:true,
//     items:4
// })